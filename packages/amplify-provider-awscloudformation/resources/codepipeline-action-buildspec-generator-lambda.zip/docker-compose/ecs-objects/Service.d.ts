import { IServiceDefinition, ServiceHealthCheck, DeploymentConfiguration, ContainerConfig, TaskConfig } from './types';
import Container from './Container';
import * as v38Types from '../compose-spec/v3.8';
declare class Service implements IServiceDefinition {
    containers: Container[];
    apiHealthcheck?: ServiceHealthCheck;
    taskResources: TaskConfig;
    containerResources: ContainerConfig;
    deploymentConfiguration: DeploymentConfiguration;
    desiredCount: number;
    constructor(containers: Container[], apiHealthcheck?: ServiceHealthCheck, dockerDeploymentConfig?: v38Types.DefinitionsDeployment2);
}
export default Service;
//# sourceMappingURL=Service.d.ts.map