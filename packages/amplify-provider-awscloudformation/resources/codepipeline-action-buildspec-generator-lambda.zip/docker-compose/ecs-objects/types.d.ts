import { ListOrDict } from '../compose-spec/v2';
export interface IServiceDefinition {
    containers: IContainerDefinitions[];
    cpu?: number | string;
    memory?: number | string;
    tags?: string[];
}
export interface IContainerDefinitions {
    build: string | IBuildConfig | undefined;
    image?: string;
    name: string;
    entrypoint?: string | string[] | undefined;
    logConfiguration: ILogConfiguration;
    portMappings: PortMappings;
}
export interface ILogConfiguration {
    logDriver: string;
    options: {
        'awslogs-group': string;
        'awslogs-region': string;
        'awslogs-stream-prefix': string;
    };
}
export interface IBuildConfig {
    context?: string;
    dockerfile?: string;
    args?: ListOrDict;
}
export declare type PortMappings = IPortMappingItem[];
interface IPortMappingItem {
    containerPort: number;
    hostPort?: number;
    protocol: string;
}
export declare type ContainerHealthCheck = IContainerHealthCheckItem;
interface IContainerHealthCheckItem {
    command?: string | string[];
    interval?: number | string;
    retries?: number;
    start_period?: string;
    timeout?: string;
}
export declare type ServiceHealthCheck = IALBHealthCheckItem;
interface IALBHealthCheckItem {
    path: string;
    port: number;
}
export declare type DeploymentConfiguration = IDeploymentConfiguration;
interface IDeploymentConfiguration {
    MaximumPercent: number;
    MinimumHealthyPercent: number;
}
export declare type TaskConfig = ITaskConfig;
interface ITaskConfig {
    memory: number;
    vCPU: number;
}
export declare type ContainerConfig = IContainerConfig;
interface IContainerConfig {
    memory: number;
    cpu: number;
}
export declare type BuildHashMap = Record<string, string>;
export {};
//# sourceMappingURL=types.d.ts.map