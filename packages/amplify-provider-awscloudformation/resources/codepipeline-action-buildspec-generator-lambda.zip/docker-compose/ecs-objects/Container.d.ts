import { IContainerDefinitions, PortMappings, IBuildConfig, ContainerHealthCheck } from './types';
import { ListOrDict } from '../compose-spec/v1';
declare class Container implements IContainerDefinitions {
    readonly defaultLogConfiguration: {
        logDriver: string;
        options: {
            'awslogs-group': string;
            'awslogs-region': string;
            'awslogs-stream-prefix': string;
        };
    };
    build: string | IBuildConfig | undefined;
    name: string;
    portMappings: PortMappings;
    logConfiguration: {
        logDriver: string;
        options: {
            'awslogs-group': string;
            'awslogs-region': string;
            'awslogs-stream-prefix': string;
        };
    };
    command?: string | string[] | undefined;
    entrypoint?: string | string[] | undefined;
    env_file?: string | string[] | undefined;
    environment?: ListOrDict | undefined;
    image?: string | undefined;
    healthcheck?: ContainerHealthCheck;
    working_dir?: string | undefined;
    user?: string | undefined;
    constructor(build: string | IBuildConfig | undefined, name: string, portMappings: PortMappings, command?: string | string[] | undefined, entrypoint?: string | string[] | undefined, env_file?: string | string[] | undefined, environment?: ListOrDict | undefined, image?: string | undefined, healthcheck?: ContainerHealthCheck | undefined, working_dir?: string | undefined, user?: string | undefined);
}
export default Container;
//# sourceMappingURL=Container.d.ts.map