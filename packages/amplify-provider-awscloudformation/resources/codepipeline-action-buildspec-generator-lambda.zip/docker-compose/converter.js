"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getContainers = void 0;
const DockerUtils_1 = require("./DockerUtils");
const Container_1 = __importDefault(require("./ecs-objects/Container"));
const isv1Schema = (obj) => {
    return obj && obj.version === undefined;
};
const hasHealthCheck = (obj) => {
    return obj.healthcheck !== undefined;
};
const mapComposeEntriesToContainer = (record) => {
    const [k, v] = record;
    const { image, ports, build, command, entrypoint, env_file, environment, working_dir, user } = v;
    const { container_name: name = k } = v;
    var healthcheck = {};
    if (hasHealthCheck(v)) {
        Object.entries(v).forEach((item) => {
            const [helthKey, healthVal] = item;
            if (healthVal.test !== undefined) {
                healthcheck = healthVal;
            }
        });
    }
    let portArray = [];
    ports === null || ports === void 0 ? void 0 : ports.forEach(item => {
        const [containerPort, hostPort = containerPort] = item.toString().split(':');
        portArray.push({
            containerPort: parseInt(containerPort, 10),
            hostPort: parseInt(hostPort, 10),
            protocol: 'tcp',
        });
    });
    return new Container_1.default(build, name, portArray, command, entrypoint, env_file, environment, image, {
        command: healthcheck.test,
        ...healthcheck,
    }, working_dir, user);
};
const convertDockerObjectToContainerArray = (yamlObject) => {
    var _a;
    let containerArr = [];
    if (isv1Schema(yamlObject)) {
        Object.entries(yamlObject).forEach((record) => {
            const container = mapComposeEntriesToContainer(record);
            containerArr.push(container);
        });
    }
    else {
        Object.entries((_a = yamlObject.services) !== null && _a !== void 0 ? _a : {}).forEach((record) => {
            const container = mapComposeEntriesToContainer(record);
            containerArr.push(container);
        });
    }
    return containerArr;
};
const findServiceDeployment = (yamlObject) => {
    var _a;
    let result = {};
    Object.entries((_a = yamlObject.services) !== null && _a !== void 0 ? _a : {}).forEach((record) => {
        const [k, v] = record;
        const { deploy } = v;
        if (deploy !== undefined) {
            result = deploy;
        }
    });
    return result;
};
function getContainers(composeContents, dockerfileContents) {
    const dockerCompose = composeContents ? DockerUtils_1.dockerComposeToObject(composeContents) : DockerUtils_1.dockerfileToObject(dockerfileContents);
    const containers = convertDockerObjectToContainerArray(dockerCompose);
    const buildmapping = {};
    containers.forEach(res => {
        if (typeof res.build === 'object') {
        }
        if (typeof res.healthcheck === 'object') {
        }
        if (res.build != undefined) {
            let buildContext = '';
            if (typeof res.build === 'object') {
                buildContext = res.build.context;
            }
            else {
                buildContext = res.build;
            }
            buildmapping[res.name] = buildContext;
        }
    });
    const buildspec = DockerUtils_1.generateBuildSpec(buildmapping);
    return {
        buildspec,
        containers
    };
}
exports.getContainers = getContainers;
//# sourceMappingURL=converter.js.map