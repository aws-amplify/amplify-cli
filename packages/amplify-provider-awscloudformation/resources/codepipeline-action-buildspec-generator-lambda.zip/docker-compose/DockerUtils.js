"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateBuildSpec = exports.dockerfileToObject = exports.dockerComposeToObject = void 0;
const js_yaml_1 = __importDefault(require("js-yaml"));
exports.dockerComposeToObject = (yamlFileContents) => {
    try {
        const doc = js_yaml_1.default.safeLoad(yamlFileContents);
        return doc;
    }
    catch (e) {
        console.log(e);
        throw e;
    }
};
exports.dockerfileToObject = (dockerfileContents) => {
    var _a;
    const lines = (_a = dockerfileContents === null || dockerfileContents === void 0 ? void 0 : dockerfileContents.split('\n')) !== null && _a !== void 0 ? _a : [];
    const ports = lines.filter(line => /^\s*EXPOSE\s+/.test(line)).map(line => (line.match(/\s+(\d+)/)|| [])[1]);
    const composeContents = `version: "3"
services:
  api:
    build: .${ports.length > 0 ? `
    ports: ${ports.map(port => `
      - '${port}:${port}'`).join('')}` : ``}
`;
    return exports.dockerComposeToObject(composeContents);
};
exports.generateBuildSpec = (containerMap) => {
    return `version: 0.2

phases:
  install:
    runtime-versions:
      docker: 19
  pre_build:
    commands:
      - echo Logging in to Amazon ECR...
      - aws --version
      - $(aws ecr get-login --region $AWS_DEFAULT_REGION --no-include-email)
      - COMMIT_HASH=$(echo $CODEBUILD_RESOLVED_SOURCE_VERSION | cut -c 1-7)
      - IMAGE_TAG=\${COMMIT_HASH:=latest}
  build:
    commands:
      - echo Build started on \`date\`
      - echo Building the Docker image...${Object.keys(containerMap).map(item => `
      - docker build -t $${item}_REPOSITORY_URI:latest ./${containerMap[item]}
      - docker tag $${item}_REPOSITORY_URI:latest $${item}_REPOSITORY_URI:$IMAGE_TAG`)}
  post_build:
    commands:
      - echo Build completed on \`date\`
      - echo Pushing the Docker images..${Object.keys(containerMap).map(item => `
      - docker push $${item}_REPOSITORY_URI:latest
      - docker push $${item}_REPOSITORY_URI:$IMAGE_TAG`)}
      - "echo \\"[${Object.keys(containerMap)
        .map(name => `{\\\\\\\"name\\\\\\\":\\\\\\\"${name}\\\\\\\", \\\\\\\"imageUri\\\\\\\":\\\\\\\"$${name}_REPOSITORY_URI\\\\\\\"}`)
        .join(',')}]\\" > imagedefinitions.json"
artifacts:
  files: imagedefinitions.json
`;
};
//# sourceMappingURL=DockerUtils.js.map