exports.handler = async (event) => {
    console.log(event);
    return event;
};