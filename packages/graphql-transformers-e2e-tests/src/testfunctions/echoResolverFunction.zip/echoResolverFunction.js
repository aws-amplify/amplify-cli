exports.handler = async (event) => {
  return event.arguments.msg;
};
